<template>
  <div
    ref="rootEl"
    class="pin-root"
    :style="rootStyle"
    @wheel.prevent="onWheel"
    @mousedown.left="onDragStart"
    @dblclick="onToggleHide"
    @contextmenu.prevent="showMenu = true"
  >
    <!-- 截图画面 -->
    <canvas
      ref="canvas"
      class="pin-canvas"
      :style="{ opacity: hidden ? 0 : 1 }"
    />

    <!-- 关闭按钮（hover 时显示） -->
    <div v-if="!hidden" class="controls">
      <button class="ctrl-btn close-btn" title="关闭" @click.stop="onClose">
        <svg viewBox="0 0 16 16" fill="currentColor">
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
        </svg>
      </button>
    </div>

    <!-- 右键菜单 -->
    <div v-if="showMenu" class="ctx-menu" @mouseleave="showMenu = false">
      <div class="menu-item" @click="onClose">关闭</div>
      <div class="menu-sep" />
      <div class="menu-item" @click="zoomIn">放大 (+)</div>
      <div class="menu-item" @click="zoomOut">缩小 (-)</div>
      <div class="menu-item" @click="resetZoom">原始大小</div>
      <div class="menu-sep" />
      <div class="menu-item" @click="toggleMouseThrough">
        {{ mouseThrough ? '取消鼠标穿透' : '鼠标穿透' }}
      </div>
    </div>

    <!-- 缩略提示（双击隐藏后显示） -->
    <div v-if="hidden" class="hidden-tip" @dblclick.stop="onToggleHide">
      <span>双击恢复</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'

interface PinInitData {
  dataUrl: string
  physWidth: number
  physHeight: number
  scaleFactor: number
  logicW: number
  logicH: number
}

const rootEl = ref<HTMLDivElement>()
const canvas = ref<HTMLCanvasElement>()

// ─── 状态 ──────────────────────────────────────────────────
let initData: PinInitData | null = null
const zoom = ref(1)
const opacity = ref(1)
const hidden = ref(false)
const showMenu = ref(false)
const mouseThrough = ref(false)

// 当前逻辑尺寸（随缩放变化）
const dispW = ref(1)
const dispH = ref(1)

const rootStyle = computed(() => ({
  width: hidden.value ? '80px' : `${dispW.value}px`,
  height: hidden.value ? '24px' : `${dispH.value}px`,
  opacity: opacity.value
}))

// ─── 初始化 ────────────────────────────────────────────────
onMounted(() => {
  const api = (window as any).pinAPI
  api?.onInit((data: PinInitData) => {
    initData = data
    dispW.value = data.logicW
    dispH.value = data.logicH
    drawImage(data)
  })

  // 键盘快捷键
  window.addEventListener('keydown', onKeyDown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', onKeyDown)
})

function drawImage(data: PinInitData) {
  const cvs = canvas.value
  if (!cvs) return
  cvs.width = data.physWidth
  cvs.height = data.physHeight
  cvs.style.width = `${data.logicW}px`
  cvs.style.height = `${data.logicH}px`

  const ctx = cvs.getContext('2d')!
  const img = new Image()
  img.onload = () => ctx.drawImage(img, 0, 0)
  img.src = data.dataUrl
}

// ─── 缩放 ──────────────────────────────────────────────────
function applyZoom(newZoom: number) {
  if (!initData) return
  zoom.value = Math.max(0.1, Math.min(5, newZoom))

  const newW = Math.round(initData.logicW * zoom.value)
  const newH = Math.round(initData.logicH * zoom.value)
  dispW.value = newW
  dispH.value = newH

  if (canvas.value) {
    canvas.value.style.width = `${newW}px`
    canvas.value.style.height = `${newH}px`
  }

  // 通知主进程调整窗口大小
  ;(window as any).pinAPI?.resize(newW, newH)
  showMenu.value = false
}

function zoomIn() { applyZoom(zoom.value * 1.25) }
function zoomOut() { applyZoom(zoom.value * 0.8) }
function resetZoom() { applyZoom(1) }

// ─── 滚轮：缩放 / 透明度 ───────────────────────────────────
function onWheel(e: WheelEvent) {
  e.preventDefault()
  if (e.ctrlKey || e.metaKey) {
    // Ctrl/Cmd + 滚轮 → 调整透明度
    const delta = e.deltaY > 0 ? -0.05 : 0.05
    opacity.value = Math.max(0.1, Math.min(1, opacity.value + delta))
  } else {
    // 滚轮 → 缩放
    const factor = e.deltaY > 0 ? 0.9 : 1.1
    applyZoom(zoom.value * factor)
  }
}

// ─── 拖拽（使用原生窗口拖拽） ──────────────────────────────
function onDragStart(e: MouseEvent) {
  // Electron 通过 -webkit-app-region: drag 处理拖拽
  // 这里只处理关闭菜单
  if (showMenu.value) showMenu.value = false
}

// ─── 隐藏 / 显示 ──────────────────────────────────────────
function onToggleHide() {
  hidden.value = !hidden.value
  if (hidden.value) {
    ;(window as any).pinAPI?.resize(80, 24)
  } else if (initData) {
    ;(window as any).pinAPI?.resize(dispW.value, dispH.value)
  }
}

// ─── 鼠标穿透 ─────────────────────────────────────────────
function toggleMouseThrough() {
  mouseThrough.value = !mouseThrough.value
  ;(window as any).pinAPI?.setIgnoreMouseEvents(mouseThrough.value)
  showMenu.value = false
}

// ─── 关闭 ─────────────────────────────────────────────────
function onClose() {
  showMenu.value = false
  ;(window as any).pinAPI?.close()
}

// ─── 键盘 ─────────────────────────────────────────────────
function onKeyDown(e: KeyboardEvent) {
  if (e.key === 'Escape') { onClose(); return }
  if (e.key === '+' || e.key === '=') { zoomIn(); return }
  if (e.key === '-') { zoomOut(); return }
  if (e.key === '0') { resetZoom(); return }
}
</script>

<style scoped>
.pin-root {
  position: fixed;
  inset: 0;
  overflow: hidden;
  border-radius: 3px;
  box-shadow: 0 2px 16px rgba(0, 0, 0, 0.35);
  /* 支持拖拽移动窗口 */
  -webkit-app-region: drag;
  user-select: none;
  transition: opacity 0.1s;
}

/* 交互元素不触发拖拽 */
.controls, .ctx-menu, .hidden-tip {
  -webkit-app-region: no-drag;
}

.pin-canvas {
  display: block;
  width: 100%;
  height: 100%;
  image-rendering: auto;
}

/* ── 悬浮控制按钮 ── */
.controls {
  position: absolute;
  top: 4px;
  right: 4px;
  display: flex;
  gap: 4px;
  opacity: 0;
  transition: opacity 0.15s;
}
.pin-root:hover .controls { opacity: 1; }

.ctrl-btn {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.55);
  color: #fff;
  cursor: pointer;
  padding: 0;
}
.ctrl-btn:hover { background: rgba(0, 0, 0, 0.82); }
.ctrl-btn svg { width: 12px; height: 12px; }
.close-btn:hover { background: #ff4d4f; }

/* ── 右键菜单 ── */
.ctx-menu {
  position: absolute;
  top: 28px;
  right: 4px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 6px 24px rgba(0,0,0,0.22);
  padding: 4px 0;
  min-width: 130px;
  z-index: 100;
}
.menu-item {
  padding: 7px 16px;
  font-size: 13px;
  color: #333;
  cursor: pointer;
  white-space: nowrap;
}
.menu-item:hover { background: #f5f5f5; }
.menu-sep {
  height: 1px;
  background: #f0f0f0;
  margin: 3px 0;
}

/* ── 缩略状态 ── */
.hidden-tip {
  width: 80px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(24, 144, 255, 0.9);
  border-radius: 3px;
  color: #fff;
  font-size: 11px;
  cursor: pointer;
}
</style>
