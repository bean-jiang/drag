import { FC, useRef, useState, useEffect, useCallback } from 'react'
import './pin.css'

// ─── 类型 ─────────────────────────────────────────────────
interface PinInitData {
  dataUrl: string
  physWidth: number
  physHeight: number
  scaleFactor: number
  logicW: number
  logicH: number
}

declare global {
  interface Window {
    pinAPI?: {
      onInit: (cb: (data: PinInitData) => void) => void
      close: () => void
      resize: (w: number, h: number) => void
      setIgnoreMouseEvents: (ignore: boolean) => void
    }
  }
}

// ─── 组件 ─────────────────────────────────────────────────
const App: FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // 不需要触发重渲的内部状态
  const initRef = useRef<PinInitData | null>(null)
  const zoomRef = useRef(1)

  // 触发重渲的 React 状态
  const [opacity, setOpacity] = useState(1)
  const [hidden, setHidden] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [mouseThrough, setMouseThrough] = useState(false)
  const [dispSize, setDispSize] = useState({ w: 1, h: 1 })

  // ── 初始化 ────────────────────────────────────────────
  useEffect(() => {
    window.pinAPI?.onInit((data) => {
      initRef.current = data
      zoomRef.current = 1
      setDispSize({ w: data.logicW, h: data.logicH })
      drawImage(data)
    })

    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  function drawImage(data: PinInitData) {
    const cvs = canvasRef.current
    if (!cvs) return
    cvs.width = data.physWidth
    cvs.height = data.physHeight
    cvs.style.width = `${data.logicW}px`
    cvs.style.height = `${data.logicH}px`
    const img = new Image()
    img.onload = () => cvs.getContext('2d')!.drawImage(img, 0, 0)
    img.src = data.dataUrl
  }

  // ── 缩放 ──────────────────────────────────────────────
  const applyZoom = useCallback((newZoom: number) => {
    const data = initRef.current
    if (!data) return
    zoomRef.current = Math.max(0.1, Math.min(5, newZoom))
    const nw = Math.round(data.logicW * zoomRef.current)
    const nh = Math.round(data.logicH * zoomRef.current)
    const cvs = canvasRef.current
    if (cvs) { cvs.style.width = `${nw}px`; cvs.style.height = `${nh}px` }
    setDispSize({ w: nw, h: nh })
    window.pinAPI?.resize(nw, nh)
    setShowMenu(false)
  }, [])

  const zoomIn = useCallback(() => applyZoom(zoomRef.current * 1.25), [applyZoom])
  const zoomOut = useCallback(() => applyZoom(zoomRef.current * 0.8), [applyZoom])
  const resetZoom = useCallback(() => applyZoom(1), [applyZoom])

  // ── 滚轮：缩放 / 透明度 ────────────────────────────────
  function onWheel(e: React.WheelEvent) {
    e.preventDefault()
    if (e.ctrlKey || e.metaKey) {
      setOpacity(prev => Math.max(0.1, Math.min(1, prev + (e.deltaY > 0 ? -0.05 : 0.05))))
    } else {
      applyZoom(zoomRef.current * (e.deltaY > 0 ? 0.9 : 1.1))
    }
  }

  // ── 隐藏 / 显示 ────────────────────────────────────────
  function toggleHide() {
    const data = initRef.current
    setHidden(prev => {
      const next = !prev
      if (next) {
        window.pinAPI?.resize(80, 24)
      } else if (data) {
        window.pinAPI?.resize(dispSize.w, dispSize.h)
      }
      return next
    })
  }

  // ── 鼠标穿透 ──────────────────────────────────────────
  function toggleMouseThrough() {
    const next = !mouseThrough
    setMouseThrough(next)
    window.pinAPI?.setIgnoreMouseEvents(next)
    setShowMenu(false)
  }

  // ── 关闭 ──────────────────────────────────────────────
  function onClose() { setShowMenu(false); window.pinAPI?.close() }

  // ── 键盘 ──────────────────────────────────────────────
  function onKeyDown(e: KeyboardEvent) {
    if (e.key === 'Escape') { onClose(); return }
    if (e.key === '+' || e.key === '=') { zoomIn(); return }
    if (e.key === '-') { zoomOut(); return }
    if (e.key === '0') { resetZoom() }
  }

  // ── 渲染 ──────────────────────────────────────────────
  if (hidden) {
    return (
      <div className="pin-root" style={{ width: 80, height: 24 }}>
        <div className="hidden-tip" onDoubleClick={toggleHide}>双击恢复</div>
      </div>
    )
  }

  return (
    <div
      className="pin-root"
      style={{ width: dispSize.w, height: dispSize.h, opacity }}
      onWheel={onWheel}
      onDoubleClick={toggleHide}
      onContextMenu={e => { e.preventDefault(); setShowMenu(v => !v) }}
    >
      {/* 截图画面 */}
      <canvas ref={canvasRef} className="pin-canvas" />

      {/* 悬浮关闭按钮 */}
      <div className="controls">
        <button className="ctrl-btn close-btn" title="关闭" onClick={e => { e.stopPropagation(); onClose() }}>
          <svg viewBox="0 0 16 16" fill="currentColor">
            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
          </svg>
        </button>
      </div>

      {/* 右键菜单 */}
      {showMenu && (
        <div className="ctx-menu" onMouseLeave={() => setShowMenu(false)}>
          <div className="menu-item danger" onClick={onClose}>关闭</div>
          <div className="menu-sep" />
          <div className="menu-item" onClick={zoomIn}>放大 (+)</div>
          <div className="menu-item" onClick={zoomOut}>缩小 (-)</div>
          <div className="menu-item" onClick={resetZoom}>原始大小 (0)</div>
          <div className="menu-sep" />
          <div className="menu-item" onClick={toggleMouseThrough}>
            {mouseThrough ? '取消鼠标穿透' : '鼠标穿透'}
          </div>
        </div>
      )}
    </div>
  )
}

export default App
