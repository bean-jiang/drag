import { FC, useRef, useState, useEffect } from 'react'
import CaptureToolbar from './components/CaptureToolbar'
import './capture.css'

// ─── 类型 ─────────────────────────────────────────────────
interface CaptureInitData {
  screenshot: string
  displayBounds: { x: number; y: number; width: number; height: number }
  scaleFactor: number
  windowList: Array<{ x: number; y: number; width: number; height: number }>
  displayIndex: number
  displayCount: number
}
interface Rect { x: number; y: number; w: number; h: number }
type AnnTool = 'none' | 'rect' | 'brush'
type AnnShape =
  | { type: 'rect'; x: number; y: number; w: number; h: number; color: string; lw: number }
  | { type: 'brush'; pts: Array<{ x: number; y: number }>; color: string; lw: number }

declare global {
  interface Window {
    captureAPI?: {
      onInit: (cb: (data: CaptureInitData) => void) => void
      complete: (dataUrl: string) => void
      save: (dataUrl: string) => Promise<boolean>
      pin: (payload: {
        dataUrl: string; physWidth: number; physHeight: number
        scaleFactor: number; originX: number; originY: number
        mouseX: number; mouseY: number
      }) => void
      cancel: () => void
    }
  }
}

// ─── 组件 ─────────────────────────────────────────────────
const App: FC = () => {
  const dpr = window.devicePixelRatio || 1

  // DOM refs
  const rootRef = useRef<HTMLDivElement>(null)
  const bgRef = useRef<HTMLCanvasElement>(null)
  const olRef = useRef<HTMLCanvasElement>(null)
  const magRef = useRef<HTMLCanvasElement>(null)

  // Canvas / drawing state refs（高频更新，不触发重渲）
  const bgCtx = useRef<CanvasRenderingContext2D | null>(null)
  const olCtx = useRef<CanvasRenderingContext2D | null>(null)
  const wList = useRef<Rect[]>([])
  const sf = useRef(1) // scaleFactor
  const sx = useRef(0), sy = useRef(0) // drag start
  const selXR = useRef(0), selYR = useRef(0)
  const selWR = useRef(0), selHR = useRef(0)
  const hover = useRef<Rect | null>(null)
  const draggingR = useRef(false)
  const selectedR = useRef(false)
  const lastMouseRef = useRef({ x: 0, y: 0 })              // 逻辑像素，窗口内坐标
  const displayBoundsRef = useRef({ x: 0, y: 0, width: 0, height: 0 })

  // 标注层
  const annRef = useRef<HTMLCanvasElement>(null)
  const annCtx = useRef<CanvasRenderingContext2D | null>(null)
  const shapes = useRef<AnnShape[]>([])
  const annDrawing = useRef(false)
  const annStart = useRef({ x: 0, y: 0 })
  const annPts = useRef<Array<{ x: number; y: number }>>([])   // 画笔笔迹点序列
  const redoStack = useRef<AnnShape[]>([])                      // 重做栈

  // React state（影响 JSX 渲染的值）
  const [isDragging, setIsDragging] = useState(false)
  const [hasSelection, setHasSelection] = useState(false)
  const [sel, setSel] = useState({ x: 0, y: 0, w: 0, h: 0 })
  const [curPx, setCurPx] = useState({ x: 0, y: 0 })
  const [annotool, setAnnotool] = useState<AnnTool>('none')
  const [canUndo, setCanUndo] = useState(false)
  const [canRedo, setCanRedo] = useState(false)

  // ── 初始化 ───────────────────────────────────────────────
  useEffect(() => {
    rootRef.current?.focus()
    window.captureAPI?.onInit(initCapture)
  }, [])

  function initCapture(data: CaptureInitData) {
    sf.current = data.scaleFactor
    displayBoundsRef.current = data.displayBounds
    wList.current = data.windowList.map(w => ({
      x: w.x - data.displayBounds.x,
      y: w.y - data.displayBounds.y,
      w: w.width,
      h: w.height
    }))
    initCanvases(data)
  }

  function initCanvases(data: CaptureInitData) {
    const W = window.innerWidth, H = window.innerHeight
    const PW = W * dpr, PH = H * dpr

    const bg = bgRef.current!, ol = olRef.current!, mg = magRef.current!, ann = annRef.current!

    bg.width = PW; bg.height = PH
    bg.style.width = `${W}px`; bg.style.height = `${H}px`
    bgCtx.current = bg.getContext('2d')!

    ol.width = PW; ol.height = PH
    ol.style.width = `${W}px`; ol.style.height = `${H}px`
    olCtx.current = ol.getContext('2d')!

    mg.width = 128 * dpr; mg.height = 64 * dpr
    mg.style.width = '128px'; mg.style.height = '64px'

    ann.width = PW; ann.height = PH
    ann.style.width = `${W}px`; ann.style.height = `${H}px`
    annCtx.current = ann.getContext('2d')!

    const img = new Image()
    img.onload = () => {
      bgCtx.current!.drawImage(img, 0, 0, PW, PH)
      drawOverlay()
    }
    img.src = data.screenshot
  }

  // ── Canvas 绘制 ─────────────────────────────────────────
  function drawOverlay() {
    const ctx = olCtx.current
    if (!ctx) return
    const W = window.innerWidth * dpr, H = window.innerHeight * dpr
    const s = dpr

    ctx.clearRect(0, 0, W, H)

    if (!selectedR.current) {
      // 全屏遮罩
      ctx.fillStyle = 'rgba(0,0,0,0.42)'
      ctx.fillRect(0, 0, W, H)
      // 悬停元素高亮
      const hr = hover.current
      if (hr) {
        ctx.clearRect(hr.x * s, hr.y * s, hr.w * s, hr.h * s)
        ctx.strokeStyle = '#1890ff'
        ctx.lineWidth = 2 * dpr
        ctx.strokeRect(hr.x * s + 1, hr.y * s + 1, hr.w * s - 2, hr.h * s - 2)
      }
    } else {
      const x = selXR.current, y = selYR.current
      const w = selWR.current, h = selHR.current
      // 挖空选区的四周遮罩
      ctx.fillStyle = 'rgba(0,0,0,0.42)'
      ctx.fillRect(0, 0, W, y * s)
      ctx.fillRect(0, (y + h) * s, W, H - (y + h) * s)
      ctx.fillRect(0, y * s, x * s, h * s)
      ctx.fillRect((x + w) * s, y * s, W - (x + w) * s, h * s)
      // 选区边框
      ctx.strokeStyle = '#1890ff'
      ctx.lineWidth = 1.5 * dpr
      ctx.strokeRect(x * s, y * s, w * s, h * s)
      drawHandles(ctx, x * s, y * s, w * s, h * s)
      if (draggingR.current) drawCrosslines(ctx, x * s, y * s, w * s, h * s)
    }
  }

  function drawHandles(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
    const r = 4 * dpr
    const pts = [
      [x, y], [x + w / 2, y], [x + w, y],
      [x + w, y + h / 2],
      [x + w, y + h], [x + w / 2, y + h], [x, y + h],
      [x, y + h / 2]
    ]
    ctx.fillStyle = '#1890ff'
    ctx.strokeStyle = '#fff'
    ctx.lineWidth = 1.5 * dpr
    for (const [hx, hy] of pts) {
      ctx.beginPath(); ctx.arc(hx, hy, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke()
    }
  }

  function drawCrosslines(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
    const W = window.innerWidth * dpr, H = window.innerHeight * dpr
    ctx.strokeStyle = 'rgba(24,144,255,0.4)'
    ctx.lineWidth = dpr
    ctx.setLineDash([4 * dpr, 4 * dpr])
    ctx.beginPath()
    ctx.moveTo(0, y); ctx.lineTo(W, y)
    ctx.moveTo(0, y + h); ctx.lineTo(W, y + h)
    ctx.moveTo(x, 0); ctx.lineTo(x, H)
    ctx.moveTo(x + w, 0); ctx.lineTo(x + w, H)
    ctx.stroke()
    ctx.setLineDash([])
  }
  // ── 标注绘制 ─────────────────────────────────────
  function drawAnnotations(preview?: AnnShape) {
    const ctx = annCtx.current
    if (!ctx) return
    const W = window.innerWidth * dpr, H = window.innerHeight * dpr
    ctx.clearRect(0, 0, W, H)
    if (!selectedR.current) return
    const sx = selXR.current * dpr, sy = selYR.current * dpr
    const sw = selWR.current * dpr, sh = selHR.current * dpr
    ctx.save()
    ctx.beginPath(); ctx.rect(sx, sy, sw, sh); ctx.clip()
    for (const s of shapes.current) renderShape(ctx, s)
    if (preview) renderShape(ctx, preview)
    ctx.restore()
  }

  function renderShape(ctx: CanvasRenderingContext2D, s: AnnShape) {
    ctx.strokeStyle = s.color
    ctx.fillStyle = s.color
    ctx.lineWidth = s.lw * dpr
    ctx.lineJoin = 'round'
    ctx.lineCap = 'round'
    if (s.type === 'rect') {
      ctx.strokeRect(s.x * dpr, s.y * dpr, s.w * dpr, s.h * dpr)
    } else if (s.type === 'brush') {
      const pts = s.pts
      if (pts.length === 0) return
      if (pts.length === 1) {
        ctx.beginPath()
        ctx.arc(pts[0].x * dpr, pts[0].y * dpr, s.lw * dpr / 2, 0, Math.PI * 2)
        ctx.fill()
        return
      }
      ctx.beginPath()
      ctx.moveTo(pts[0].x * dpr, pts[0].y * dpr)
      for (let i = 1; i < pts.length - 1; i++) {
        const mx = (pts[i].x + pts[i + 1].x) / 2
        const my = (pts[i].y + pts[i + 1].y) / 2
        ctx.quadraticCurveTo(pts[i].x * dpr, pts[i].y * dpr, mx * dpr, my * dpr)
      }
      ctx.lineTo(pts[pts.length - 1].x * dpr, pts[pts.length - 1].y * dpr)
      ctx.stroke()
    }
  }

  function buildAnnShape(ex: number, ey: number): AnnShape | null {
    const x = Math.min(annStart.current.x, ex)
    const y = Math.min(annStart.current.y, ey)
    const w = Math.abs(ex - annStart.current.x)
    const h = Math.abs(ey - annStart.current.y)
    if (w < 3 || h < 3) return null
    return { type: 'rect', x, y, w, h, color: '#ff3b3b', lw: 2 }
  }
  // ── 放大镜 ──────────────────────────────────────────────
  function updateMagnifier(mx: number, my: number) {
    const mg = magRef.current
    if (!mg || selectedR.current) return
    const mCtx = mg.getContext('2d')!
    const zW = 15, zH = 7
    const px = Math.max(0, mx * dpr - Math.floor(zW / 2))
    const py = Math.max(0, my * dpr - Math.floor(zH / 2))
    mCtx.clearRect(0, 0, mg.width, mg.height)
    mCtx.imageSmoothingEnabled = false
    mCtx.drawImage(bgRef.current!, px, py, zW, zH, 0, 0, mg.width, mg.height)
    mCtx.strokeStyle = 'rgba(255,255,255,0.8)'
    mCtx.lineWidth = 1
    mCtx.beginPath()
    mCtx.moveTo(mg.width / 2, 0); mCtx.lineTo(mg.width / 2, mg.height)
    mCtx.moveTo(0, mg.height / 2); mCtx.lineTo(mg.width, mg.height / 2)
    mCtx.stroke()
  }

  // ── 元素自动检测 ────────────────────────────────────────
  function findHovered(mx: number, my: number): Rect | null {
    let best: Rect | null = null, bestArea = Infinity
    for (const r of wList.current) {
      if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) {
        const area = r.w * r.h
        if (area < bestArea) { bestArea = area; best = r }
      }
    }
    return best
  }

  // ── 鼠标事件 ────────────────────────────────────────────
  function onMouseDown(e: React.MouseEvent) {
    if (e.button !== 0) return
    e.preventDefault()

    // 标注绘制模式：选区内按下开始绘制，选区外忽略（不重置选区）
    if (annotool !== 'none' && selectedR.current) {
      const { x, y, w, h } = { x: selXR.current, y: selYR.current, w: selWR.current, h: selHR.current }
      if (e.clientX >= x && e.clientX <= x + w && e.clientY >= y && e.clientY <= y + h) {
        annDrawing.current = true
        annStart.current = { x: e.clientX, y: e.clientY }
        if (annotool === 'brush') annPts.current = [{ x: e.clientX, y: e.clientY }]
      }
      return
    }

    if (selectedR.current) {
      // 点击选区外部 → 重置
      const { x, y, w, h } = { x: selXR.current, y: selYR.current, w: selWR.current, h: selHR.current }
      if (e.clientX < x || e.clientX > x + w || e.clientY < y || e.clientY > y + h) {
        selectedR.current = false; selWR.current = 0; selHR.current = 0
        shapes.current = []; redoStack.current = []; drawAnnotations(); setAnnotool('none')
        setHasSelection(false); setSel({ x: 0, y: 0, w: 0, h: 0 })
        setCanUndo(false); setCanRedo(false)
        drawOverlay()
      }
      return
    }

    // 点击悬停的元素 → 以该元素作为初始选区
    if (hover.current) {
      const r = hover.current
      selXR.current = r.x; selYR.current = r.y
      selWR.current = r.w; selHR.current = r.h
      selectedR.current = true
      setHasSelection(true); setSel({ x: r.x, y: r.y, w: r.w, h: r.h })
      drawOverlay(); return
    }

    sx.current = e.clientX; sy.current = e.clientY
    draggingR.current = true; setIsDragging(true)
  }

  function onMouseMove(e: React.MouseEvent) {
    const mx = e.clientX, my = e.clientY
    lastMouseRef.current = { x: mx, y: my }
    setCurPx({ x: Math.round(mx * dpr), y: Math.round(my * dpr) })

    if (annDrawing.current) {
      if (annotool === 'brush') {
        annPts.current.push({ x: mx, y: my })
        drawAnnotations({ type: 'brush', pts: [...annPts.current], color: '#ff3b3b', lw: 2 })
      } else {
        drawAnnotations(buildAnnShape(mx, my) ?? undefined)
      }
      return
    }

    if (draggingR.current) {
      const nx = Math.min(mx, sx.current), ny = Math.min(my, sy.current)
      const nw = Math.round(Math.abs(mx - sx.current))
      const nh = Math.round(Math.abs(my - sy.current))
      selXR.current = nx; selYR.current = ny
      selWR.current = nw; selHR.current = nh
      setSel({ x: nx, y: ny, w: nw, h: nh })
      drawOverlay(); return
    }

    if (!selectedR.current) {
      const prev = hover.current
      hover.current = findHovered(mx, my)
      if (prev?.x !== hover.current?.x || prev?.y !== hover.current?.y) drawOverlay()
      updateMagnifier(mx, my)
    }
  }

  function onMouseUp(e: React.MouseEvent) {
    if (annDrawing.current) {
      annDrawing.current = false
      if (annotool === 'brush') {
        annPts.current.push({ x: e.clientX, y: e.clientY })
        if (annPts.current.length >= 2) {
          shapes.current.push({ type: 'brush', pts: [...annPts.current], color: '#ff3b3b', lw: 2 })
          redoStack.current = []
          setCanUndo(true); setCanRedo(false)
        }
        annPts.current = []
      } else {
        const shape = buildAnnShape(e.clientX, e.clientY)
        if (shape) {
          shapes.current.push(shape)
          redoStack.current = []
          setCanUndo(true); setCanRedo(false)
        }
      }
      drawAnnotations()
      return
    }

    if (!draggingR.current) return
    draggingR.current = false; setIsDragging(false)
    const w = Math.round(Math.abs(e.clientX - sx.current))
    const h = Math.round(Math.abs(e.clientY - sy.current))
    if (w < 4 || h < 4) { selWR.current = 0; selHR.current = 0; drawOverlay(); return }
    selWR.current = w; selHR.current = h
    selectedR.current = true
    setHasSelection(true)
    setSel({ x: selXR.current, y: selYR.current, w, h })
    drawOverlay()
  }

  function onUndo() {
    if (shapes.current.length === 0) return
    redoStack.current.push(shapes.current.pop()!)
    drawAnnotations()
    setCanUndo(shapes.current.length > 0)
    setCanRedo(true)
  }

  function onRedo() {
    if (redoStack.current.length === 0) return
    shapes.current.push(redoStack.current.pop()!)
    drawAnnotations()
    setCanUndo(true)
    setCanRedo(redoStack.current.length > 0)
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
      e.preventDefault()
      if (e.shiftKey) onRedo(); else onUndo()
      return
    }
    if (e.key === 'Escape') { onCancel(); return }
    if (e.key === 'Enter') { onCopy() }
  }

  // ── 裁剪选区 ────────────────────────────────────────────
  function cropSelection(): string {
    const physX = Math.round(selXR.current * dpr), physY = Math.round(selYR.current * dpr)
    const physW = Math.round(selWR.current * dpr), physH = Math.round(selHR.current * dpr)
    const crop = document.createElement('canvas')
    crop.width = physW; crop.height = physH
    const ctx = crop.getContext('2d')!
    ctx.drawImage(bgRef.current!, physX, physY, physW, physH, 0, 0, physW, physH)
    if (annRef.current) ctx.drawImage(annRef.current, physX, physY, physW, physH, 0, 0, physW, physH)
    return crop.toDataURL('image/png')
  }

  // ── 工具栏操作 ──────────────────────────────────────────
  function onCopy() {
    if (!selectedR.current) return
    window.captureAPI?.complete(cropSelection())
  }
  async function onSave() {
    if (!selectedR.current) return
    await window.captureAPI?.save(cropSelection())
  }
  function onPin() {
    if (!selectedR.current) return
    // 将窗口内逻辑坐标转换为全局屏幕坐标
    const db = displayBoundsRef.current
    window.captureAPI?.pin({
      dataUrl: cropSelection(),
      physWidth: Math.round(selWR.current * dpr),
      physHeight: Math.round(selHR.current * dpr),
      scaleFactor: sf.current,
      originX: db.x + selXR.current,
      originY: db.y + selYR.current,
      mouseX: db.x + lastMouseRef.current.x,
      mouseY: db.y + lastMouseRef.current.y
    })
  }
  function onCancel() { window.captureAPI?.cancel() }

  // ── 计算 UI 位置 ────────────────────────────────────────
  const magLeft = Math.min(curPx.x / dpr + 20, window.innerWidth - 148)
  const magTop = Math.min(curPx.y / dpr + 20, window.innerHeight - 90)

  const TOOLBAR_W = 490, TOOLBAR_H = 46
  const tbLeft = Math.max(4, Math.min(sel.x + sel.w - TOOLBAR_W, window.innerWidth - TOOLBAR_W - 4))
  const tbTop = sel.y + sel.h + 8 + TOOLBAR_H < window.innerHeight
    ? sel.y + sel.h + 8
    : sel.y - TOOLBAR_H - 8

  const sbLeft = sel.x + 4
  const sbTop = sel.y > 24 ? sel.y - 24 : sel.y + sel.h + 4

  // ── 渲染 ────────────────────────────────────────────────
  return (
    <div
      ref={rootRef}
      className="capture-root"
      tabIndex={0}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onKeyDown={onKeyDown}
      onContextMenu={e => { e.preventDefault(); onCancel() }}
    >
      {/* 截图背景 */}
      <canvas ref={bgRef} className="layer bg-layer" />

      {/* 遮罩 + 选区绘制层 */}
      <canvas ref={olRef} className="layer ol-layer" />

      {/* 标注层 */}
      <canvas ref={annRef} className="layer ann-layer" />

      {/* 放大镜（始终挂载，隐藏控制 */}
      <div
        className="magnifier-wrap"
        style={{ left: magLeft, top: magTop, display: hasSelection ? 'none' : undefined }}
      >
        <canvas ref={magRef} className="mag-canvas" />
        <div className="coord-info">{curPx.x}, {curPx.y}</div>
      </div>

      {/* 选区尺寸提示 */}
      {isDragging && sel.w > 0 && sel.h > 0 && (
        <div className="size-badge" style={{ left: sbLeft, top: sbTop }}>
          {sel.w} × {sel.h}
        </div>
      )}

      {/* 工具栏 */}
      {hasSelection && !isDragging && (
        <CaptureToolbar
          style={{ left: tbLeft, top: tbTop }}
          tool={annotool}
          onToolChange={setAnnotool}
          canUndo={canUndo}
          canRedo={canRedo}
          onUndo={onUndo}
          onRedo={onRedo}
          onCopy={onCopy}
          onSave={onSave}
          onPin={onPin}
          onCancel={onCancel}
        />
      )}
    </div>
  )
}

export default App
