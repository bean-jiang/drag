<template>
  <div class="toolbar">
    <button class="btn btn-icon" title="复制到剪贴板 (Enter)" @click="$emit('copy')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="9" y="9" width="13" height="13" rx="2"/>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
      </svg>
      <span>复制</span>
    </button>

    <button class="btn btn-icon" title="保存到文件" @click="$emit('save')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
        <polyline points="17 21 17 13 7 13 7 21"/>
        <polyline points="7 3 7 8 15 8"/>
      </svg>
      <span>保存</span>
    </button>

    <div class="sep" />

    <button class="btn btn-primary btn-icon" title="贴到屏幕 (F3)" @click="$emit('pin')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="12" y1="17" x2="12" y2="22"/>
        <path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V17z"/>
      </svg>
      <span>贴图</span>
    </button>

    <button class="btn btn-icon btn-cancel" title="取消 (ESC)" @click="$emit('cancel')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <line x1="18" y1="6" x2="6" y2="18"/>
        <line x1="6" y1="6" x2="18" y2="18"/>
      </svg>
    </button>
  </div>
</template>

<script setup lang="ts">
defineEmits(['copy', 'save', 'pin', 'cancel'])
</script>

<style scoped>
.toolbar {
  position: absolute;
  z-index: 20;
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 5px 8px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.28), 0 1px 4px rgba(0,0,0,0.12);
  pointer-events: all;
  user-select: none;
}

.sep {
  width: 1px;
  height: 22px;
  background: #e8e8e8;
  margin: 0 4px;
}

.btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 5px 10px;
  border: none;
  border-radius: 6px;
  background: transparent;
  color: #333;
  font-size: 12px;
  cursor: pointer;
  transition: background 0.12s;
  white-space: nowrap;
}
.btn:hover { background: #f5f5f5; }
.btn svg { width: 15px; height: 15px; }

.btn-primary {
  color: #1890ff;
}
.btn-primary:hover { background: #e6f4ff; }

.btn-cancel { color: #999; padding: 5px 7px; }
.btn-cancel:hover { background: #fff0f0; color: #ff4d4f; }
</style>
