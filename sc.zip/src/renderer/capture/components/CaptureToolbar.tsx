import { CSSProperties, FC } from 'react'

type AnnTool = 'none' | 'rect' | 'brush'

interface Props {
  style?: CSSProperties
  tool: AnnTool
  onToolChange: (t: AnnTool) => void
  canUndo: boolean
  canRedo: boolean
  onUndo: () => void
  onRedo: () => void
  onCopy: () => void
  onSave: () => void
  onPin: () => void
  onCancel: () => void
}

const CaptureToolbar: FC<Props> = ({ style, tool, onToolChange, canUndo, canRedo, onUndo, onRedo, onCopy, onSave, onPin, onCancel }) => (
  // stopPropagation 防止 mousedown 冒泡到截图根元素，避免触发选区重置
  <div className="toolbar" style={style} onMouseDown={e => e.stopPropagation()}>

    {/* 标注工具 */}
    <button
      className={`btn${tool === 'rect' ? ' btn-active' : ''}`}
      title="画矩形框 (R)"
      onClick={() => onToolChange(tool === 'rect' ? 'none' : 'rect')}
    >
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <rect x="3" y="5" width="18" height="14" rx="1.5" />
      </svg>
      矩形
    </button>

    <button
      className={`btn${tool === 'brush' ? ' btn-active' : ''}`}
      title="画笔"
      onClick={() => onToolChange(tool === 'brush' ? 'none' : 'brush')}
    >
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <path d="M12 20h9" />
        <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" />
      </svg>
      画笔
    </button>

    <div className="sep" />

    <button className="btn" title="撤销 (Ctrl+Z)" onClick={onUndo} disabled={!canUndo}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <path d="M9 14 4 9l5-5" />
        <path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11" />
      </svg>
      撤销
    </button>

    <button className="btn" title="重做 (Ctrl+Shift+Z)" onClick={onRedo} disabled={!canRedo}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <path d="M15 14l5-5-5-5" />
        <path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13" />
      </svg>
      重做
    </button>

    <div className="sep" />

    <button className="btn" title="复制到剪贴板 (Enter)" onClick={onCopy}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <rect x="9" y="9" width="13" height="13" rx="2" />
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
      </svg>
      复制
    </button>

    <button className="btn" title="保存到文件" onClick={onSave}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
        <polyline points="17 21 17 13 7 13 7 21" />
        <polyline points="7 3 7 8 15 8" />
      </svg>
      保存
    </button>

    <div className="sep" />

    <button className="btn btn-primary" title="贴到屏幕 (F3)" onClick={onPin}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <line x1="12" y1="17" x2="12" y2="22" />
        <path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V17z" />
      </svg>
      贴图
    </button>

    <button className="btn btn-cancel" title="取消 (ESC)" onClick={onCancel}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
        <line x1="18" y1="6" x2="6" y2="18" />
        <line x1="6" y1="6" x2="18" y2="18" />
      </svg>
    </button>
  </div >
)

export default CaptureToolbar
