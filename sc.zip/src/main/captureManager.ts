/**
 * CaptureManager — 管理截图覆盖层窗口
 * 支持多屏、高分辨率
 */
import {
  BrowserWindow,
  desktopCapturer,
  screen,
  nativeImage,
  Display
} from 'electron'
import { join } from 'path'
import { getWindowList } from './windowDetector'

const isDev = process.env.NODE_ENV === 'development'

export class CaptureManager {
  private windows: BrowserWindow[] = []
  private capturing = false

  /** F1 触发入口 */
  async startCapture(): Promise<void> {
    if (this.capturing) return
    this.capturing = true

    try {
      const displays = screen.getAllDisplays()

      // 并行：截图 + 获取系统窗口列表
      const [screenshots, windowList] = await Promise.all([
        this.captureAllDisplays(displays),
        Promise.resolve(getWindowList())
      ])

      // 为每个显示器创建覆盖层窗口
      for (let i = 0; i < displays.length; i++) {
        const win = this.createOverlayWindow(displays[i])
        this.windows.push(win)

        const initData = {
          screenshot: screenshots[i],
          displayBounds: displays[i].bounds,
          scaleFactor: displays[i].scaleFactor,
          windowList,
          displayIndex: i,
          displayCount: displays.length
        }

        win.webContents.once('did-finish-load', () => {
          win.webContents.send('capture:init', initData)
          win.show()
          win.focus()
        })
      }
    } catch (e) {
      console.error('[CaptureManager] startCapture error:', e)
      this.capturing = false
    }
  }

  /** 截取所有显示器屏幕 */
  private async captureAllDisplays(displays: Display[]): Promise<string[]> {
    // 求最大物理分辨率（用于请求缩略图尺寸）
    const maxW = Math.max(...displays.map((d) => d.size.width * d.scaleFactor))
    const maxH = Math.max(...displays.map((d) => d.size.height * d.scaleFactor))

    const sources = await desktopCapturer.getSources({
      types: ['screen'],
      thumbnailSize: { width: maxW, height: maxH }
    })

    return displays.map((display) => {
      // 匹配显示器 ID（macOS display_id 是数字字符串）
      const source =
        sources.find((s) => s.display_id === String(display.id)) ?? sources[0]

      if (!source) return ''

      // 以正确的物理分辨率重新生成缩略图，转 JPEG 减小传输体积
      const physW = display.size.width * display.scaleFactor
      const physH = display.size.height * display.scaleFactor
      const resized = source.thumbnail.resize({
        width: physW,
        height: physH,
        quality: 'best'
      })

      // JPEG 质量 92 —— 兼顾清晰度与传输效率
      const jpegBuf = resized.toJPEG(92)
      return `data:image/jpeg;base64,${jpegBuf.toString('base64')}`
    })
  }

  /** 为指定显示器创建全屏透明覆盖层 */
  private createOverlayWindow(display: Display): BrowserWindow {
    const { x, y, width, height } = display.bounds

    const win = new BrowserWindow({
      x,
      y,
      width,
      height,
      frame: false,
      transparent: true,
      alwaysOnTop: true,
      skipTaskbar: true,
      show: false,
      movable: false,
      resizable: false,
      enableLargerThanScreen: true,
      fullscreenable: false,
      hasShadow: false,
      webPreferences: {
        preload: join(__dirname, '../preload/capture.js'),
        contextIsolation: true,
        nodeIntegration: false,
        backgroundThrottling: false
      }
    })

    // 置于最顶层（screen-saver 级别），覆盖全屏幕包含 Dock/菜单栏
    win.setAlwaysOnTop(true, 'screen-saver')
    win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true })

    if (isDev && process.env.ELECTRON_RENDERER_URL) {
      win.loadURL(`${process.env.ELECTRON_RENDERER_URL}/capture/index.html`)
    } else {
      win.loadFile(join(__dirname, '../renderer/capture/index.html'))
    }

    win.on('closed', () => {
      const idx = this.windows.indexOf(win)
      if (idx !== -1) this.windows.splice(idx, 1)
    })

    return win
  }

  /** 关闭全部覆盖层窗口，重置状态 */
  closeAll(): void {
    this.windows.forEach((w) => {
      if (!w.isDestroyed()) w.close()
    })
    this.windows = []
    this.capturing = false
  }
}
