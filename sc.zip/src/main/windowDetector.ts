/**
 * macOS / Windows 系统窗口边界检测
 * 用于截图时自动高亮界面元素
 */
import { execFileSync } from 'child_process'
import { writeFileSync, existsSync } from 'fs'
import { join } from 'path'
import { tmpdir } from 'os'
import { platform } from 'process'

export interface WindowBounds {
  x: number
  y: number
  width: number
  height: number
}

// Swift 源码：通过 CGWindowList 获取屏幕上所有可见窗口坐标
const SWIFT_CODE = `import Cocoa
let list = CGWindowListCopyWindowInfo(
  [.optionOnScreenOnly, .excludeDesktopElements],
  kCGNullWindowID
)! as NSArray
var result: [[String: Double]] = []
for item in list {
    let d = item as! NSDictionary
    guard let bounds = d[kCGWindowBounds as String] as? NSDictionary,
          let layer  = d[kCGWindowLayer  as String] as? Int,
          layer == 0
    else { continue }
    let x = (bounds["X"] as? Double) ?? 0
    let y = (bounds["Y"] as? Double) ?? 0
    let w = (bounds["Width"]  as? Double) ?? 0
    let h = (bounds["Height"] as? Double) ?? 0
    if w > 30 && h > 30 {
        result.append(["x": x, "y": y, "w": w, "h": h])
    }
}
let data = try! JSONSerialization.data(withJSONObject: result)
print(String(data: data, encoding: .utf8)!)
`

let swiftTmpPath = ''

function ensureSwiftFile(): string {
  if (!swiftTmpPath) {
    swiftTmpPath = join(tmpdir(), '_tj_wl.swift')
    writeFileSync(swiftTmpPath, SWIFT_CODE, 'utf8')
  }
  return swiftTmpPath
}

/**
 * 获取当前屏幕上所有可见窗口的边界矩形列表
 * macOS: 使用 CGWindowList
 * 其他平台: 返回空数组（不支持自动元素检测）
 */
export function getWindowList(): WindowBounds[] {
  try {
    if (platform !== 'darwin') return []

    const swiftFile = ensureSwiftFile()
    const output = execFileSync('swift', [swiftFile], { timeout: 3000 })
      .toString()
      .trim()

    if (!output) return []

    const raw = JSON.parse(output) as Array<{
      x: number
      y: number
      w: number
      h: number
    }>
    return raw.map((w) => ({ x: w.x, y: w.y, width: w.w, height: w.h }))
  } catch (e) {
    // swift 不可用或超时时静默失败
    return []
  }
}
