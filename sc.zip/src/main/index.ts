/**
 * 主进程入口
 * 负责：系统托盘 / 全局快捷键 / IPC 路由
 */
import {
  app,
  globalShortcut,
  ipcMain,
  Tray,
  Menu,
  nativeImage,
  clipboard,
  BrowserWindow,
  dialog,
  screen
} from 'electron'
import { join } from 'path'
import { CaptureManager } from './captureManager'
import { PinManager } from './pinManager'

let tray: Tray | null = null
const captureManager = new CaptureManager()
const pinManager = new PinManager()

/** 最近一次截图数据，供 Cmd+T 贴图使用 */
let lastCapture: {
  dataUrl: string
  physWidth: number
  physHeight: number
  scaleFactor: number
} | null = null

// ─── 应用生命周期 ─────────────────────────────────────
app.whenReady().then(() => {
  setupTray()
  setupGlobalShortcuts()
  setupIpcHandlers()
})

// macOS：关闭所有窗口后不退出，继续在后台运行
app.on('window-all-closed', (e: Event) => {
  if (process.platform !== 'darwin') {
    // Windows/Linux 也保持托盘后台运行
    e.preventDefault()
  }
})

app.on('will-quit', () => {
  globalShortcut.unregisterAll()
})

// ─── 系统托盘 ─────────────────────────────────────────
function setupTray(): void {
  // 打包后资源在 process.resourcesPath/resources/，开发时相对于 out/main/
  const iconPath = app.isPackaged
    ? join(process.resourcesPath, 'resources', 'tray.png')
    : join(__dirname, '../../resources/tray.png')
  let icon: Electron.NativeImage

  try {
    icon = nativeImage.createFromPath(iconPath)
    if (icon.isEmpty()) throw new Error('empty')
    // macOS 模板图片自动适应深/浅色菜单栏
    if (process.platform === 'darwin') icon.setTemplateImage(true)
    icon = icon.resize({ width: 16, height: 16 })
  } catch {
    // 内嵌最小 16×16 SVG 作为保底图标
    const svg = Buffer.from(
      `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16">
        <rect x="1" y="4" width="14" height="9" rx="2" fill="none" stroke="currentColor" stroke-width="1.5"/>
        <circle cx="8" cy="8.5" r="2.5" fill="none" stroke="currentColor" stroke-width="1.5"/>
        <path d="M5.5 4 L6 2 h4 l0.5 2" stroke="currentColor" stroke-width="1.5" fill="none"/>
      </svg>`
    )
    icon = nativeImage.createFromDataURL(
      `data:image/svg+xml;base64,${svg.toString('base64')}`
    )
  }

  tray = new Tray(icon)
  tray.setToolTip('潼浚截图  (cmd+Y 截图 / cmd+T 贴图)')

  const contextMenu = Menu.buildFromTemplate([
    {
      label: '截图',
      accelerator: 'Cmd+Y',
      click: () => captureManager.startCapture()
    },
    {
      label: '贴图（粘贴剪贴板图片）',
      accelerator: 'Cmd+T',
      click: () => pinClipboardImage()
    },
    { type: 'separator' },
    {
      label: '退出',
      click: () => {
        globalShortcut.unregisterAll()
        app.exit(0)
      }
    }
  ])

  tray.setContextMenu(contextMenu)
  tray.on('click', () => captureManager.startCapture())
}

// ─── 全局快捷键 ───────────────────────────────────────
function setupGlobalShortcuts(): void {
  const shotOk = globalShortcut.register('Command+Y', () => captureManager.startCapture())
  const pinOk = globalShortcut.register('Command+T', () => pinClipboardImage())
  if (!shotOk) console.error('[shortcut] Cmd+Y 注册失败，可能被其他程序占用')
  if (!pinOk) console.error('[shortcut] Cmd+T 注册失败，可能被其他程序占用或系统拦截')
}

/** 将最近截图（或剪贴板图片）贴到屏幕上（鼠标所在位置） */
function pinClipboardImage(): void {
  const cursor = screen.getCursorScreenPoint()

  if (lastCapture) {
    // 优先使用最近一次截图（scaleFactor 已知，尺寸准确）
    const { dataUrl, physWidth, physHeight, scaleFactor } = lastCapture
    pinManager.createPinWindow(dataUrl, physWidth, physHeight, scaleFactor, 0, 0, cursor.x, cursor.y)
    return
  }

  // 回退：读取剪贴板图片
  const img = clipboard.readImage()
  if (img.isEmpty()) return
  const { width: physWidth, height: physHeight } = img.getSize()
  const display = screen.getDisplayNearestPoint(cursor)
  pinManager.createPinWindow(
    img.toDataURL(),
    physWidth,
    physHeight,
    display.scaleFactor,
    0,
    0,
    cursor.x,
    cursor.y
  )
}

// ─── IPC 处理 ─────────────────────────────────────────
function setupIpcHandlers(): void {
  /** 截图完成：复制到剪贴板 */
  ipcMain.on(
    'capture:complete',
    (_e, dataUrl: string) => {
      const img = nativeImage.createFromDataURL(dataUrl)
      clipboard.writeImage(img)
      // 记录截图数据，供 Cmd+T 快捷键直接贴图
      const captureWin = BrowserWindow.fromWebContents(_e.sender)
      const display = captureWin
        ? screen.getDisplayNearestPoint(captureWin.getBounds())
        : screen.getPrimaryDisplay()
      const { width: physWidth, height: physHeight } = img.getSize()
      lastCapture = { dataUrl, physWidth, physHeight, scaleFactor: display.scaleFactor }
      captureManager.closeAll()
    }
  )

  /** 截图完成：保存到文件 */
  ipcMain.handle('capture:save', async (_e, dataUrl: string) => {
    const { filePath } = await dialog.showSaveDialog({
      title: '保存截图',
      defaultPath: `screenshot_${Date.now()}.png`,
      filters: [{ name: 'PNG 图片', extensions: ['png'] }]
    })
    if (!filePath) return false

    const { writeFileSync } = await import('fs')
    const base64 = dataUrl.replace(/^data:image\/\w+;base64,/, '')
    writeFileSync(filePath, Buffer.from(base64, 'base64'))
    captureManager.closeAll()
    return true
  })

  /** 截图钉在屏幕上 */
  ipcMain.on(
    'capture:pin',
    (
      _e,
      payload: {
        dataUrl: string
        physWidth: number
        physHeight: number
        scaleFactor: number
        originX: number
        originY: number
        mouseX: number
        mouseY: number
      }
    ) => {
      captureManager.closeAll()
      pinManager.createPinWindow(
        payload.dataUrl,
        payload.physWidth,
        payload.physHeight,
        payload.scaleFactor,
        payload.originX,
        payload.originY,
        payload.mouseX,
        payload.mouseY
      )
    }
  )

  /** 取消截图 */
  ipcMain.on('capture:cancel', () => captureManager.closeAll())

  /** 贴图窗口关闭 */
  ipcMain.on('pin:close', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    if (win && !win.isDestroyed()) win.close()
  })

  /** 贴图窗口调整大小（缩放） */
  ipcMain.on('pin:resize', (event, width: number, height: number) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    if (win && !win.isDestroyed()) {
      win.setSize(Math.max(40, width), Math.max(40, height), false)
    }
  })

  /** 贴图穿透鼠标 */
  ipcMain.on('pin:setIgnoreMouseEvents', (event, ignore: boolean) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    if (win && !win.isDestroyed()) {
      win.setIgnoreMouseEvents(ignore, { forward: true })
    }
  })
}
