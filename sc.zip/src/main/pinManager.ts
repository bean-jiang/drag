/**
 * PinManager — 管理"贴图"置顶窗口
 * 截图可以永久置顶贴在屏幕上
 */
import { BrowserWindow, ipcMain, nativeImage, screen } from 'electron'
import { join } from 'path'

const isDev = process.env.NODE_ENV === 'development'

export class PinManager {
  private windows: BrowserWindow[] = []

  /**
   * 创建贴图窗口
   * @param dataUrl  PNG/JPEG data URL
   * @param physWidth  物理像素宽度
   * @param physHeight 物理像素高度
   * @param scaleFactor 所在显示器缩放倍率
   * @param originX    截图原点 X（屏幕坐标，逻辑像素）
   * @param originY    截图原点 Y（屏幕坐标，逻辑像素）
   * @param mouseX     点击"贴图"时鼠标 X（屏幕坐标，用于定位到鼠标所在屏幕）
   * @param mouseY     点击"贴图"时鼠标 Y（屏幕坐标）
   */
  createPinWindow(
    dataUrl: string,
    physWidth: number,
    physHeight: number,
    scaleFactor: number,
    originX: number,
    originY: number,
    mouseX: number,
    mouseY: number
  ): void {
    // 逻辑像素尺寸（根据截图所在屏幕的缩放率换算）
    const logicW = Math.round(physWidth / scaleFactor)
    const logicH = Math.round(physHeight / scaleFactor)

    // 以鼠标位置确定目标屏幕，贴图跟随鼠标落点的屏幕
    const display = screen.getDisplayNearestPoint({ x: mouseX, y: mouseY })
    const { bounds } = display

    // 以鼠标位置为中心放置贴图，并限制在屏幕可见范围内
    const centerX = mouseX - Math.round(logicW / 2)
    const centerY = mouseY - Math.round(logicH / 2)
    const winX = Math.min(Math.max(centerX, bounds.x), bounds.x + bounds.width - logicW - 1)
    const winY = Math.min(Math.max(centerY, bounds.y), bounds.y + bounds.height - logicH - 1)

    const win = new BrowserWindow({
      x: winX,
      y: winY,
      width: logicW,
      height: logicH,
      frame: false,
      transparent: true,
      alwaysOnTop: true,
      skipTaskbar: false,
      resizable: false,
      movable: true,
      hasShadow: true,
      webPreferences: {
        preload: join(__dirname, '../preload/pin.js'),
        contextIsolation: true,
        nodeIntegration: false,
        backgroundThrottling: false
      }
    })

    win.setAlwaysOnTop(true, 'floating')
    win.setVisibleOnAllWorkspaces(true)

    const initData = { dataUrl, physWidth, physHeight, scaleFactor, logicW, logicH }

    if (isDev && process.env.ELECTRON_RENDERER_URL) {
      win.loadURL(`${process.env.ELECTRON_RENDERER_URL}/pin/index.html`).then(() => {
        win.webContents.send('pin:init', initData)
      })
    } else {
      win.loadFile(join(__dirname, '../renderer/pin/index.html')).then(() => {
        win.webContents.send('pin:init', initData)
      })
    }

    win.on('closed', () => {
      const idx = this.windows.indexOf(win)
      if (idx !== -1) this.windows.splice(idx, 1)
    })

    this.windows.push(win)
  }

  /** 调整贴图窗口大小（缩放时） */
  resizePinWindow(winId: number, width: number, height: number): void {
    const win = BrowserWindow.fromId(winId)
    if (win && !win.isDestroyed()) {
      win.setSize(width, height, false)
    }
  }

  closeAll(): void {
    this.windows.forEach((w) => { if (!w.isDestroyed()) w.close() })
    this.windows = []
  }
}
