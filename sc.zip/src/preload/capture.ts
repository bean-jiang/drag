/**
 * 截图覆盖层窗口的预加载脚本
 * 通过 contextBridge 安全暴露 IPC API 给渲染器
 */
import { contextBridge, ipcRenderer } from 'electron'

export interface CaptureInitData {
  screenshot: string       // JPEG data URL（该显示器的截图）
  displayBounds: {         // 显示器逻辑坐标（供坐标转换参考）
    x: number
    y: number
    width: number
    height: number
  }
  scaleFactor: number      // 高分屏倍率（如 Retina = 2）
  windowList: Array<{      // OS 窗口列表（用于元素自动检测）
    x: number
    y: number
    width: number
    height: number
  }>
  displayIndex: number     // 当前显示器索引
  displayCount: number     // 显示器总数
}

export interface CaptureAPI {
  /** 主进程 → 渲染器：初始化截图数据 */
  onInit: (cb: (data: CaptureInitData) => void) => void
  /** 截图完成，复制到剪贴板 */
  complete: (dataUrl: string) => void
  /** 截图完成，保存到文件 */
  save: (dataUrl: string) => Promise<boolean>
  /** 截图钉在屏幕上 */
  pin: (payload: {
    dataUrl: string
    physWidth: number
    physHeight: number
    scaleFactor: number
    originX: number
    originY: number
  }) => void
  /** 取消截图 */
  cancel: () => void
}

// 预加载时就注册监听，缓冲数据，避免 React useEffect 注册晚于消息到达
let _bufferedInit: CaptureInitData | null = null
let _initCb: ((data: CaptureInitData) => void) | null = null
ipcRenderer.on('capture:init', (_e, data: CaptureInitData) => {
  _bufferedInit = data
  if (_initCb) { _initCb(data); _initCb = null }
})

contextBridge.exposeInMainWorld('captureAPI', {
  onInit: (cb: (data: CaptureInitData) => void) => {
    if (_bufferedInit) {
      cb(_bufferedInit)
    } else {
      _initCb = cb
    }
  },
  complete: (dataUrl: string) =>
    ipcRenderer.send('capture:complete', dataUrl),
  save: (dataUrl: string) =>
    ipcRenderer.invoke('capture:save', dataUrl),
  pin: (payload: object) =>
    ipcRenderer.send('capture:pin', payload),
  cancel: () =>
    ipcRenderer.send('capture:cancel')
} as CaptureAPI)
