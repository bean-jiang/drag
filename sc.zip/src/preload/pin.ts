/**
 * 贴图窗口的预加载脚本
 */
import { contextBridge, ipcRenderer } from 'electron'

export interface PinInitData {
  dataUrl: string
  physWidth: number
  physHeight: number
  scaleFactor: number
  logicW: number
  logicH: number
}

export interface PinAPI {
  onInit: (cb: (data: PinInitData) => void) => void
  close: () => void
  resize: (width: number, height: number) => void
  setIgnoreMouseEvents: (ignore: boolean) => void
}

// 预加载时就注册监听，缓冲数据，避免 React useEffect 注册晚于消息到达
let _bufferedInit: PinInitData | null = null
let _initCb: ((data: PinInitData) => void) | null = null
ipcRenderer.on('pin:init', (_e, data: PinInitData) => {
  _bufferedInit = data
  if (_initCb) { _initCb(data); _initCb = null }
})

contextBridge.exposeInMainWorld('pinAPI', {
  onInit: (cb: (data: PinInitData) => void) => {
    if (_bufferedInit) {
      cb(_bufferedInit)
    } else {
      _initCb = cb
    }
  },
  close: () =>
    ipcRenderer.send('pin:close'),
  resize: (w: number, h: number) =>
    ipcRenderer.send('pin:resize', w, h),
  setIgnoreMouseEvents: (ignore: boolean) =>
    ipcRenderer.send('pin:setIgnoreMouseEvents', ignore)
} as PinAPI)
