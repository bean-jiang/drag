import { resolve } from 'path'
import { defineConfig, externalizeDepsPlugin } from 'electron-vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  main: {
    plugins: [externalizeDepsPlugin()]
  },
  preload: {
    plugins: [externalizeDepsPlugin()],
    build: {
      rollupOptions: {
        input: {
          capture: resolve(__dirname, 'src/preload/capture.ts'),
          pin: resolve(__dirname, 'src/preload/pin.ts')
        }
      }
    }
  },
  renderer: {
    plugins: [react()],
    build: {
      rollupOptions: {
        input: {
          capture: resolve(__dirname, 'src/renderer/capture/index.html'),
          pin: resolve(__dirname, 'src/renderer/pin/index.html')
        }
      }
    }
  }
})
