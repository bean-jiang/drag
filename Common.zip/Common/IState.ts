import { Enemy } from "../Enemy/Enemy"
import { Player } from "../Player/Player"

export interface IState {

    update(dt: number)

    //fixedUpdate(dt:number)

    enter()

    exit()

}


export interface IPlayerState extends IState {
    target : Player
    
    stateType : PlayerStateType

    update(dt: number)

    //fixUpdate(dt:number)

    enter()

    exit()
}

export interface IEnemyState extends IState {
    target : Enemy
    
    stateType : EnemyStateType;

    update(dt: number)

    //fixUpdate(dt:number)

    enter()

    exit()

}

export enum PlayerStateType {
    IDLE    = "Idle",
    ATTACK  = "Attack",
    ATTACK1 = "Attack1",
    ATTACK2 = "Attack2",
    RUN     = "Run",
    JUMP    = "Jump",
    Fall    = "Fall",
    CRASH   = "Crash",
    HIT     = "Hit"
}

export enum EnemyStateType {
    IDLE = "Idle",
    HIT  = "Hit"
}