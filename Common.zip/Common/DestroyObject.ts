import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('DestroyObject')
export class DestroyObject extends Component {
    @property(Number)
    DestroyTimer:number = 1;

    start() {
        this.scheduleOnce(() => {
            this.node.destroy();
        },this.DestroyTimer)
    }
}

