import { Fixedupdate } from "../Common/Fixedupdate"
import { EnemyStateType, IEnemyState, IPlayerState, PlayerStateType } from "../Common/IState"
import { Player } from "../Player/Player"
import { find, Label } from "cc"
import { Enemy } from "../Enemy/Enemy"

export class StateMachine { 
    curState :  IPlayerState | IEnemyState

    prevState :  IPlayerState | IEnemyState

    states : IPlayerState[] | IEnemyState[]  = [];

    target : Player | Enemy;

    label : Label

    init(target : Player | Enemy) {
        this.target = target;
        this.label = find("Canvas/Debug/Label").getComponent(Label);
    }

    addState(state) {
        this.states.push(state)
    }

    changeState(stateType : PlayerStateType | EnemyStateType) {
        if(this.curState && this.curState.stateType == stateType) {
            return
        }
        
        if(this.curState) {
            this.prevState = this.curState;
            this.curState.exit();
        }
        
        this.curState = this.getState(stateType)
        
        this.curState.enter()
    }

    getState(stateType: PlayerStateType | EnemyStateType) {
        for(let i = 0; i < this.states.length; i++) {
            if(this.states[i].stateType == stateType) {
                return this.states[i]
            }
        }
        return null
    }
    
    update(dt: number) {
        if(this.label) {
            let str  = this.curState.stateType.toString();
            /*if(this.prevState) {
                str += " "+this.prevState.stateType.toString();
            }*/
            this.label.string = str;
        }
        Fixedupdate.getInstance().update(dt, this.fixedUpdate.bind(this));
    }

    fixedUpdate(dt:number) {
        if(this.curState) {
            this.curState.update(dt)   
        }
    }
}