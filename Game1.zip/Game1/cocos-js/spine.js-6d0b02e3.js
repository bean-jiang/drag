System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/spine.js.mem-90a4faeb.bin")}}}));
