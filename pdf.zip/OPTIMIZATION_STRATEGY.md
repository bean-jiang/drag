# PDF 转 TIFF 体积优化策略

## 1. 问题背景

原始 PDF 约 818KB，但转换后的 TIFF 达到约 69.3MB，体积膨胀明显，造成存储、传输和后续处理成本上升。

## 2. 根因分析

转换体积过大的主要原因是以下三个因素叠加：

1. 像素数据使用 RGBA 四通道直接写入，未做有效压缩。
2. 默认高 DPI 渲染，单页像素总量过大。
3. 多页 TIFF 采用接近原始位图方式保存，数据冗余高。

结论：本质是“高分辨率 + 多通道 + 低压缩”的组合导致体积放大。

## 3. 优化目标

1. 在可接受清晰度下显著降低 TIFF 文件体积。
2. 保持纯 Node.js 实现，不依赖外部命令行工具。
3. 保留参数可调能力，满足不同业务场景。

## 4. 修改策略

### 4.1 默认参数改为小体积优先

1. DPI 默认值由 300 调整为 200。
2. 颜色模式默认改为 gray（灰度）。
3. 压缩默认改为 packbits。

该组合适合扫描件、合同、票据、表单等以文字为主的文档。

### 4.2 去除不必要通道

1. 从 RGBA 转换为 RGB 或 Gray。
2. 默认使用 Gray 单通道，直接减少每像素数据量。

理论上，通道层面从 4 通道降到 1 通道，可显著降低基础数据体积。

### 4.3 增加可控压缩能力

新增参数：

1. --compression packbits|none
2. --colorspace gray|rgb

默认采用 PackBits 压缩，在文档类图像上通常有明显收益。

### 4.4 统一编码流程

无论 single 还是 multipage 输出模式，都统一走“像素转换 + 压缩编码 + TIFF 组装”的流程，避免单页和多页策略不一致。

## 5. 质量与体积取舍建议

### 5.1 推荐配置

文字文档优先（默认）：
- --dpi 200 --colorspace gray --compression packbits

兼顾颜色信息：
- --dpi 160~200 --colorspace rgb --compression packbits

图像细节优先：
- --dpi 250~300 --colorspace rgb --compression packbits

### 5.2 参数影响规律

1. DPI 每提升一级，像素数量近似按平方增加，体积增长明显。
2. colorspace 从 gray 切换到 rgb，像素数据通常约增至 3 倍。
3. 关闭压缩（none）会使体积显著上升，应仅用于少数兼容性场景。

## 6. 本次实现点

已在转换脚本中落实以下改动：

1. 默认参数调整为：dpi=200、compression=packbits、colorspace=gray。
2. 新增参数解析：--compression、--colorspace。
3. 新增颜色转换逻辑：RGBA -> Gray、RGBA -> RGB。
4. 新增 PackBits 编码逻辑，并写入 TIFF 压缩标记。
5. 单页/多页输出统一复用同一编码管线。

## 7. 验证结果

在本地样本验证中，未压缩 RGB 与压缩 Gray 的输出体积差距明显，说明优化方向有效。

说明：实际压缩比例与 PDF 内容强相关。纯文字、留白较多页面收益更高；高频彩色照片页面收益相对较低。

## 8. 使用建议

建议默认使用以下命令：

node pdf-to-tiff.js -i t.pdf -o output.tiff --dpi 200 --compression packbits --colorspace gray

若必须保留彩色，可使用：

node pdf-to-tiff.js -i t.pdf -o output.tiff --dpi 160 --compression packbits --colorspace rgb

## 9. 后续可选增强

1. 增加 --profile 参数（text、mixed、photo）自动映射参数。
2. 增加页面级自适应策略（按页复杂度动态调整 DPI 或颜色模式）。
3. 引入可选高级压缩后端（例如 LZW/Deflate）作为增强模式。
