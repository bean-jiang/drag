#!/usr/bin/env node
import { access, mkdir, readFile, writeFile } from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";
import process from "node:process";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";
import { createCanvas } from "@napi-rs/canvas";
import UTIF from "utif";

function parseArgs(argv) {
  const args = {
    input: "",
    output: "",
    dpi: 160,
    mode: "multipage",
    compression: "packbits",
    colorspace: "rgb",
  };

  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];

    if (token === "--input" || token === "-i") {
      args.input = argv[i + 1] || "";
      i += 1;
      continue;
    }

    if (token === "--output" || token === "-o") {
      args.output = argv[i + 1] || "";
      i += 1;
      continue;
    }

    if (token === "--dpi") {
      const val = Number(argv[i + 1]);
      if (!Number.isNaN(val) && val > 0) {
        args.dpi = val;
      }
      i += 1;
      continue;
    }

    if (token === "--mode") {
      const val = argv[i + 1];
      if (val === "single" || val === "multipage") {
        args.mode = val;
      }
      i += 1;
      continue;
    }

    if (token === "--compression") {
      const val = argv[i + 1];
      if (val === "none" || val === "packbits") {
        args.compression = val;
      }
      i += 1;
      continue;
    }

    if (token === "--colorspace") {
      const val = argv[i + 1];
      if (val === "rgb" || val === "gray") {
        args.colorspace = val;
      }
      i += 1;
      continue;
    }

  }

  return args;
}

function printHelp() {
  console.log(`
PDF 转 TIFF 工具

用法:
  node pdf-to-tiff.js -i input.pdf -o output.tiff [--dpi 200] [--mode multipage|single]
                      [--compression packbits|none] [--colorspace gray|rgb]

参数:
  -i, --input         输入 PDF 文件路径（必填）
  -o, --output        输出 TIFF 文件路径（必填）
      --dpi           渲染精度，默认 200
      --mode          multipage(默认): 输出一个多页 TIFF
                      single: 每页输出一个 TIFF 文件，文件名自动加序号
      --compression   TIFF 压缩方式，默认 packbits（体积更小）
      --colorspace    颜色模式，默认 gray（体积更小）

依赖:
  npm install
`);
}

async function exists(filePath) {
  try {
    await access(filePath, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function ensureParentDir(outputPath) {
  const dir = path.dirname(outputPath);
  if (dir && dir !== ".") {
    await mkdir(dir, { recursive: true });
  }
}

function createIfd(width, height, stripOffset, stripByteCount, encoding) {
  const sampleBits = encoding.samplesPerPixel === 1 ? [8] : [8, 8, 8];
  return {
    t256: [width],
    t257: [height],
    t258: sampleBits,
    t259: [encoding.compressionTag],
    t262: [encoding.photometricTag],
    t273: [stripOffset],
    t277: [encoding.samplesPerPixel],
    t278: [height],
    t279: [stripByteCount],
    t282: [1],
    t283: [1],
    t284: [1],
    t286: [0],
    t287: [0],
    t296: [1],
    t305: ["pdf-to-tiff-tool"],
  };
}

function rgbaToRgb(rgba) {
  const out = new Uint8Array(Math.floor(rgba.length / 4) * 3);
  let j = 0;
  for (let i = 0; i < rgba.length; i += 4) {
    out[j] = rgba[i];
    out[j + 1] = rgba[i + 1];
    out[j + 2] = rgba[i + 2];
    j += 3;
  }
  return out;
}

function rgbaToGray(rgba) {
  const out = new Uint8Array(Math.floor(rgba.length / 4));
  let j = 0;
  for (let i = 0; i < rgba.length; i += 4) {
    const r = rgba[i];
    const g = rgba[i + 1];
    const b = rgba[i + 2];
    out[j] = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
    j += 1;
  }
  return out;
}

function packBitsEncode(input) {
  const out = [];
  let i = 0;

  while (i < input.length) {
    let runLen = 1;
    while (
      i + runLen < input.length &&
      runLen < 128 &&
      input[i] === input[i + runLen]
    ) {
      runLen += 1;
    }

    if (runLen >= 3) {
      out.push((256 - (runLen - 1)) & 0xff);
      out.push(input[i]);
      i += runLen;
      continue;
    }

    const literalStart = i;
    let literalLen = 0;

    while (i < input.length && literalLen < 128) {
      runLen = 1;
      while (
        i + runLen < input.length &&
        runLen < 128 &&
        input[i] === input[i + runLen]
      ) {
        runLen += 1;
      }

      if (runLen >= 3) {
        break;
      }

      i += 1;
      literalLen += 1;
    }

    out.push((literalLen - 1) & 0xff);
    for (let k = 0; k < literalLen; k += 1) {
      out.push(input[literalStart + k]);
    }
  }

  return Uint8Array.from(out);
}

function encodePagePixels(rgba, colorspace) {
  if (colorspace === "gray") {
    return {
      bytes: rgbaToGray(rgba),
      samplesPerPixel: 1,
      photometricTag: 1,
    };
  }

  return {
    bytes: rgbaToRgb(rgba),
    samplesPerPixel: 3,
    photometricTag: 2,
  };
}

function encodeTiffPageBytes(rawBytes, { compression }) {
  if (compression === "packbits") {
    return {
      bytes: packBitsEncode(rawBytes),
      compressionTag: 32773,
    };
  }

  return {
    bytes: rawBytes,
    compressionTag: 1,
  };
}

function buildTiffBufferFromPages(pages, options) {
  const encodedPages = pages.map((page) => {
    const pixelEncoding = encodePagePixels(page.rgba, options.colorspace);
    const compressionEncoding = encodeTiffPageBytes(pixelEncoding.bytes, {
      compression: options.compression,
    });

    return {
      width: page.width,
      height: page.height,
      bytes: compressionEncoding.bytes,
      samplesPerPixel: pixelEncoding.samplesPerPixel,
      photometricTag: pixelEncoding.photometricTag,
      compressionTag: compressionEncoding.compressionTag,
    };
  });

  const ifds = encodedPages.map((page) =>
    createIfd(page.width, page.height, 0, page.bytes.length, {
      samplesPerPixel: page.samplesPerPixel,
      photometricTag: page.photometricTag,
      compressionTag: page.compressionTag,
    }),
  );

  const firstPassHeader = new Uint8Array(UTIF.encode(ifds));
  let nextOffset = firstPassHeader.length;
  for (let i = 0; i < encodedPages.length; i += 1) {
    ifds[i].t273 = [nextOffset];
    ifds[i].t279 = [encodedPages[i].bytes.length];
    nextOffset += encodedPages[i].bytes.length;
  }

  const header = new Uint8Array(UTIF.encode(ifds));
  const totalLen = encodedPages.reduce((sum, page) => sum + page.bytes.length, 0);
  const out = new Uint8Array(header.length + totalLen);
  out.set(header, 0);

  let offset = header.length;
  for (const page of encodedPages) {
    out.set(page.bytes, offset);
    offset += page.bytes.length;
  }

  return out;
}

async function renderPdfPages({ input, dpi }) {
  const src = await readFile(input);
  const loadingTask = pdfjs.getDocument({
    data: new Uint8Array(src),
    disableWorker: true,
    useSystemFonts: true,
  });
  const doc = await loadingTask.promise;
  const scale = dpi / 72;
  const pages = [];

  for (let pageNo = 1; pageNo <= doc.numPages; pageNo += 1) {
    const page = await doc.getPage(pageNo);
    const viewport = page.getViewport({ scale });
    const width = Math.max(1, Math.round(viewport.width));
    const height = Math.max(1, Math.round(viewport.height));

    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext("2d");

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, width, height);

    await page.render({ canvasContext: ctx, viewport }).promise;

    const rgba = ctx.getImageData(0, 0, width, height).data;
    pages.push({ width, height, rgba });
  }

  await loadingTask.destroy();
  return pages;
}

async function convertPdfToTiffSequence({ input, output, dpi, compression, colorspace }) {
  const pages = await renderPdfPages({ input, dpi });

  const ext = path.extname(output) || ".tiff";
  const base = output.slice(0, output.length - ext.length) || output;

  for (let pageNo = 1; pageNo <= pages.length; pageNo += 1) {
    const page = pages[pageNo - 1];
    const tiffBytes = buildTiffBufferFromPages([page], {
      compression,
      colorspace,
    });
    const pagePath = `${base}-${String(pageNo).padStart(3, "0")}${ext}`;
    await writeFile(pagePath, Buffer.from(tiffBytes));
  }
}

async function convertPdfToMultiPageTiff({ input, output, dpi, compression, colorspace }) {
  const pages = await renderPdfPages({ input, dpi });

  if (pages.length === 0) {
    throw new Error("PDF 没有可用页面");
  }
  const out = buildTiffBufferFromPages(pages, {
    compression,
    colorspace,
  });
  await writeFile(output, Buffer.from(out));
}

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.input || !args.output) {
    printHelp();
    process.exitCode = 1;
    return;
  }

  const inputPath = path.resolve(args.input);
  const outputPath = path.resolve(args.output);

  if (!(await exists(inputPath))) {
    console.error(`输入文件不存在: ${inputPath}`);
    process.exitCode = 1;
    return;
  }

  await ensureParentDir(outputPath);

  try {
    if (args.mode === "single") {
      await convertPdfToTiffSequence({
        input: inputPath,
        output: outputPath,
        dpi: args.dpi,
        compression: args.compression,
        colorspace: args.colorspace,
      });
      console.log(`转换完成（纯 Node.js）: ${outputPath}（按页序号输出）`);
      return;
    }

    await convertPdfToMultiPageTiff({
      input: inputPath,
      output: outputPath,
      dpi: args.dpi,
      compression: args.compression,
      colorspace: args.colorspace,
    });
    console.log(`转换完成（纯 Node.js）: ${outputPath}（多页单文件）`);
  } catch (error) {
    console.error("转换失败:", error.message);
    process.exitCode = 1;
  }
}

main();
