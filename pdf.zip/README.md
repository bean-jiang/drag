# PDF 转 TIFF（Node.js）

这个小工具使用纯 Node.js 将 PDF 渲染后输出 TIFF，不依赖 ImageMagick。

## 1. 安装依赖

```bash
npm install
```

## 2. 执行转换

```bash
node pdf-to-tiff.js -i t.pdf -o out.tiff
```

或使用 npm script：

```bash
npm run convert -- -i t.pdf -o out.tiff
```

## 3. 可选参数

- `--dpi 200`：输出清晰度，默认 `200`
- `--mode multipage|single`：
  - `multipage`（默认）输出一个多页 `tiff`
  - `single` 每页输出一个 `tiff`（自动加序号）
- `--compression packbits|none`：TIFF 压缩方式，默认 `packbits`
- `--colorspace gray|rgb`：输出颜色模式，默认 `gray`

示例：

```bash
node pdf-to-tiff.js -i t.pdf -o output.tiff --dpi 200 --mode multipage --compression packbits --colorspace gray
```
