# PDF 转 TIFF（Node.js）

这个小工具使用 Node.js 调用系统转换程序，将 PDF 转成 TIFF。

## 1. 安装依赖（macOS）

推荐安装 ImageMagick + Ghostscript：

```bash
brew install imagemagick ghostscript
```

也可以只装 Ghostscript：

```bash
brew install ghostscript
```

## 2. 执行转换

```bash
node pdf-to-tiff.js -i t.pdf -o out.tiff
```

或使用 npm script：

```bash
npm run convert -- -i t.pdf -o out.tiff
```

## 3. 可选参数

- `--dpi 300`：输出清晰度，默认 `300`
- `--mode multipage|single`：
  - `multipage`（默认）输出一个多页 `tiff`
  - `single` 每页输出一个 `tiff`（自动加序号）
- `--compression lzw`：TIFF 压缩方式（ImageMagick 模式下生效）

示例：

```bash
node pdf-to-tiff.js -i t.pdf -o output.tiff --dpi 400 --mode multipage --compression lzw
```
