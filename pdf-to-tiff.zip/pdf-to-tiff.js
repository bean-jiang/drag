#!/usr/bin/env node
import { access, mkdir, readFile, writeFile } from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";
import process from "node:process";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";
import { createCanvas } from "@napi-rs/canvas";
import UTIF from "utif";

function parseArgs(argv) {
  const args = {
    input: "",
    output: "",
    dpi: 300,
    mode: "multipage",
  };

  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];

    if (token === "--input" || token === "-i") {
      args.input = argv[i + 1] || "";
      i += 1;
      continue;
    }

    if (token === "--output" || token === "-o") {
      args.output = argv[i + 1] || "";
      i += 1;
      continue;
    }

    if (token === "--dpi") {
      const val = Number(argv[i + 1]);
      if (!Number.isNaN(val) && val > 0) {
        args.dpi = val;
      }
      i += 1;
      continue;
    }

    if (token === "--mode") {
      const val = argv[i + 1];
      if (val === "single" || val === "multipage") {
        args.mode = val;
      }
      i += 1;
      continue;
    }

  }

  return args;
}

function printHelp() {
  console.log(`
PDF 转 TIFF 工具

用法:
  node pdf-to-tiff.js -i input.pdf -o output.tiff [--dpi 300] [--mode multipage|single]

参数:
  -i, --input         输入 PDF 文件路径（必填）
  -o, --output        输出 TIFF 文件路径（必填）
      --dpi           渲染精度，默认 300
      --mode          multipage(默认): 输出一个多页 TIFF
                      single: 每页输出一个 TIFF 文件，文件名自动加序号

依赖:
  npm install
`);
}

async function exists(filePath) {
  try {
    await access(filePath, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function ensureParentDir(outputPath) {
  const dir = path.dirname(outputPath);
  if (dir && dir !== ".") {
    await mkdir(dir, { recursive: true });
  }
}

function createIfd(width, height, stripOffset) {
  return {
    t256: [width],
    t257: [height],
    t258: [8, 8, 8, 8],
    t259: [1],
    t262: [2],
    t273: [stripOffset],
    t277: [4],
    t278: [height],
    t279: [width * height * 4],
    t282: [1],
    t283: [1],
    t284: [1],
    t286: [0],
    t287: [0],
    t296: [1],
    t305: ["pdf-to-tiff-tool"],
    t338: [1],
  };
}

async function renderPdfPages({ input, dpi }) {
  const src = await readFile(input);
  const loadingTask = pdfjs.getDocument({
    data: new Uint8Array(src),
    disableWorker: true,
    useSystemFonts: true,
  });
  const doc = await loadingTask.promise;
  const scale = dpi / 72;
  const pages = [];

  for (let pageNo = 1; pageNo <= doc.numPages; pageNo += 1) {
    const page = await doc.getPage(pageNo);
    const viewport = page.getViewport({ scale });
    const width = Math.max(1, Math.round(viewport.width));
    const height = Math.max(1, Math.round(viewport.height));

    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext("2d");

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, width, height);

    await page.render({ canvasContext: ctx, viewport }).promise;

    const rgba = ctx.getImageData(0, 0, width, height).data;
    pages.push({ width, height, rgba });
  }

  await loadingTask.destroy();
  return pages;
}

async function convertPdfToTiffSequence({ input, output, dpi }) {
  const pages = await renderPdfPages({ input, dpi });

  const ext = path.extname(output) || ".tiff";
  const base = output.slice(0, output.length - ext.length) || output;

  for (let pageNo = 1; pageNo <= pages.length; pageNo += 1) {
    const { width, height, rgba } = pages[pageNo - 1];
    const tiffArrayBuffer = UTIF.encodeImage(rgba, width, height);
    const pagePath = `${base}-${String(pageNo).padStart(3, "0")}${ext}`;
    await writeFile(pagePath, Buffer.from(tiffArrayBuffer));
  }
}

async function convertPdfToMultiPageTiff({ input, output, dpi }) {
  const pages = await renderPdfPages({ input, dpi });

  if (pages.length === 0) {
    throw new Error("PDF 没有可用页面");
  }

  const ifds = pages.map((page) => createIfd(page.width, page.height, 0));

  const firstPassHeader = new Uint8Array(UTIF.encode(ifds));
  let nextOffset = firstPassHeader.length;
  for (let i = 0; i < pages.length; i += 1) {
    ifds[i].t273 = [nextOffset];
    nextOffset += pages[i].rgba.length;
  }

  const header = new Uint8Array(UTIF.encode(ifds));
  const totalLen = pages.reduce((sum, page) => sum + page.rgba.length, 0);
  const out = new Uint8Array(header.length + totalLen);
  out.set(header, 0);

  let offset = header.length;
  for (const page of pages) {
    out.set(page.rgba, offset);
    offset += page.rgba.length;
  }

  await writeFile(output, Buffer.from(out));
}

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.input || !args.output) {
    printHelp();
    process.exitCode = 1;
    return;
  }

  const inputPath = path.resolve(args.input);
  const outputPath = path.resolve(args.output);

  if (!(await exists(inputPath))) {
    console.error(`输入文件不存在: ${inputPath}`);
    process.exitCode = 1;
    return;
  }

  await ensureParentDir(outputPath);

  try {
    if (args.mode === "single") {
      await convertPdfToTiffSequence({
        input: inputPath,
        output: outputPath,
        dpi: args.dpi,
      });
      console.log(`转换完成（纯 Node.js）: ${outputPath}（按页序号输出）`);
      return;
    }

    await convertPdfToMultiPageTiff({
      input: inputPath,
      output: outputPath,
      dpi: args.dpi,
    });
    console.log(`转换完成（纯 Node.js）: ${outputPath}（多页单文件）`);
  } catch (error) {
    console.error("转换失败:", error.message);
    process.exitCode = 1;
  }
}

main();
